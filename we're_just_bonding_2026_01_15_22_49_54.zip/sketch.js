//general
let game = true;
//sprites
let corePlayer;
let electron;
let enemys;
let status = "reactive nonmetal";
let statusColor = "blue";
let statusShape;
let powerfulEnemys;
let laserEnemys;
let lasers;
//movement variables
let acceleration = 0.15;
let maxSpeed = 3;
let friction = 0.97;
let velocityX = 0;
let velocityY = 0;
let electronVelX = 0;
let electronVelY = 0;
let electronFriction = 0.96;
let electronDelay = 0.05;
//sprite attributes
let ionaztionenergy = 13.6;
let maxEnemiesOnScreen = 5;
let maxTotalEnemies = 20; 
let enemyCount = 0;
let enemiesKilled = 0; 
let lastSpawnTime = 0;
let spawnInterval = 2000;
let enableSheild = false;
let shieldRadius = 50;
let shieldDuration = 3000;
let shieldCooldown = 5000;
let shieldStartTime = 0;
let shieldCooldownStart = 0;
let canUseShield = true;
let hasSpawnedElectronThisWave = false;
let electronCount = 1;
let powerfulEnemySpeed = 2;
let laserEnemySpeed = 1.5;
let laserCooldown = 2000;
let laserSpeed = 5;
function setup() {
  createCanvas(600, 600);
  noStroke();
  initGame();
}
function initGame() {
  //status objects
  statusShape = new Sprite(20, 20, 10, 's');
  statusShape.color = statusColor;
  //player
  corePlayer = new Sprite(200, 200, 45, "k");
  corePlayer.color = "red";
  corePlayer.friction = 0;
  electron = new Group();
  electron.color = "green";
  electron.friction = 0;
  new electron.Sprite(100, 200, 20, "k");
  //enemys
  enemys = new Group();
  enemys.color = "purple";
  //powerful enemys
  powerfulEnemys = new Group();
  powerfulEnemys.color = 'red';
  //laser enemys
  laserEnemys = new Group();
  laserEnemys.color = 'orange';
  //lasers
  lasers = new Group();
  lasers.color = 'yellow';
  lasers.diameter = 8;
  
  // Reset game variables
  game = true;
  velocityX = 0;
  velocityY = 0;
  electronVelX = 0;
  electronVelY = 0;
  ionaztionenergy = 13.6;
  enemyCount = 0;
  enemiesKilled = 0;
  lastSpawnTime = 0;
  enableSheild = false;
  canUseShield = true;
  electronCount = 1;
  status = "reactive nonmetal";
  statusColor = "blue";
}
function draw() {
  background("black");

  if (game) {
    playerMovement();
    iceMovement();
    enemyMovement();
    playerDeath();
    playerDefence();
    updateShield();
    elementGroupChange();
    drawShield();
    win();
    fill("white");
    noStroke();
    textSize(11);
    text(status, 30, 23);
    text("ionazation energy level = " + ionaztionenergy, 20, 40);
    text("Enemies killed: " + enemiesKilled + " / " + maxTotalEnemies, 20, 100);
    text("Enemies spawned: " + enemyCount + " / " + maxTotalEnemies, 20, 120);
    text("Regular enemies: " + enemys.length, 20, 140);
    text("Powerful enemies: " + powerfulEnemys.length, 20, 160);
    text("Laser enemies: " + laserEnemys.length, 20, 180);
    text("Total electrons: " + electron.length, 20, 200);
    text("Press E to activate shield (3s duration)", 20, 60);

    if (enableSheild) {
      let timeLeft = shieldDuration - (millis() - shieldStartTime);
      text("Shield: ACTIVE (" + (timeLeft / 1000).toFixed(1) + "s)", 20, 80);
    } else if (!canUseShield) {
      let cooldownLeft = shieldCooldown - (millis() - shieldCooldownStart);
      text(
        "Shield: RECHARGING (" + (cooldownLeft / 1000).toFixed(1) + "s)",
        20,
        80
      );
    } else {
      text("Shield: READY", 20, 80);
    }
  } else {
    title();
  }
}
function drawShield() {
  if (enableSheild) {
    push();
    noFill();
    stroke(0, 255, 255, 200);
    strokeWeight(3);
    circle(corePlayer.x, corePlayer.y, shieldRadius * 2);
    fill(0, 255, 255, 30);
    noStroke();
    circle(corePlayer.x, corePlayer.y, shieldRadius * 2);
    pop();
  }
}
function enemyMovement() {
  if (enemys.length === 0 && powerfulEnemys.length === 0 && laserEnemys.length === 0 && 
      enemyCount >= maxTotalEnemies && enemiesKilled >= maxTotalEnemies) {
    enemyCount = 0;
    enemiesKilled = 0;
    new electron.Sprite(random(400), random(400), 20, "k");
  }

  let totalEnemiesOnScreen = enemys.length + powerfulEnemys.length + laserEnemys.length;

  if (totalEnemiesOnScreen < maxEnemiesOnScreen && enemyCount < maxTotalEnemies && 
      millis() - lastSpawnTime > spawnInterval) {
    spawnEnemy();
    lastSpawnTime = millis();
  }

  for (let i = enemys.length - 1; i >= 0; i--) {
    let e = enemys[i];
    moveEnemyTowardsPlayer(e, 1);
    checkEnemyCollision(e);
  }
  
  for (let i = powerfulEnemys.length - 1; i >= 0; i--) {
    let e = powerfulEnemys[i];
    moveEnemyTowardsPlayer(e, powerfulEnemySpeed);
    checkEnemyCollision(e);
  }

  for (let i = laserEnemys.length - 1; i >= 0; i--) {
    let e = laserEnemys[i];
    moveEnemyTowardsPlayer(e, laserEnemySpeed);
    
    if (!e.lastShot || millis() - e.lastShot > laserCooldown) {
      shootLaser(e);
      e.lastShot = millis();
    }
    
    checkEnemyCollision(e);
  }
  
  for (let i = lasers.length - 1; i >= 0; i--) {
    let laser = lasers[i];
    laser.x += laser.velX;
    laser.y += laser.velY;
    
    if (laser.x < 0 || laser.x > width || laser.y < 0 || laser.y > height) {
      laser.remove();
      continue;
    }
    
    let d = dist(laser.x, laser.y, corePlayer.x, corePlayer.y);
    if (d < corePlayer.diameter / 2 + laser.diameter / 2) {
      laser.remove();
      ionaztionenergy -= 2;
    }
  }
}
function moveEnemyTowardsPlayer(e, speed) {
  let direction = enableSheild ? -1 : 1;
  
  if (e.x < corePlayer.x) {
    e.x += speed * direction;
  }
  if (e.x > corePlayer.x) {
    e.x -= speed * direction;
  }
  if (e.y < corePlayer.y) {
    e.y += speed * direction;
  }
  if (e.y > corePlayer.y) {
    e.y -= speed * direction;
  }
}
function checkEnemyCollision(e) {
  let d = dist(e.x, e.y, corePlayer.x, corePlayer.y);
  if (enableSheild && d < shieldRadius + e.diameter / 2) {
    e.remove();
    enemiesKilled++;
  } else if (d < corePlayer.diameter / 2 + e.diameter / 2) {
    ionaztionenergy -= 1;
    e.remove();
  }
}
function shootLaser(enemy) {
  let angle = atan2(corePlayer.y - enemy.y, corePlayer.x - enemy.x);
  let laser = new lasers.Sprite(enemy.x, enemy.y, 8, "k");
  laser.velX = cos(angle) * laserSpeed;
  laser.velY = sin(angle) * laserSpeed;
}
function iceMovement() {
  velocityX = constrain(velocityX, -maxSpeed, maxSpeed);
  velocityY = constrain(velocityY, -maxSpeed, maxSpeed);
  velocityX *= friction;
  velocityY *= friction;
  if (abs(velocityX) < 0.01) velocityX = 0;
  if (abs(velocityY) < 0.01) velocityY = 0;
  corePlayer.x += velocityX;
  corePlayer.y += velocityY;

  for (let e of electron) {
    electronVelX += velocityX * electronDelay;
    electronVelY += velocityY * electronDelay;
    electronVelX *= electronFriction;
    electronVelY *= electronFriction;
    if (abs(electronVelX) < 0.01) electronVelX = 0;
    if (abs(electronVelY) < 0.01) electronVelY = 0;
    e.x += electronVelX;
    e.y += electronVelY;
  }
}
function playerMovement() {
  stroke("white");
  fill("white");
  for (let e of electron) {
    line(corePlayer.x, corePlayer.y, e.x, e.y);
  }
  noStroke();

  if (kb.pressing("w") || kb.pressing(UP_ARROW)) {
    velocityY -= acceleration;
  }
  if (kb.pressing("s") || kb.pressing(DOWN_ARROW)) {
    velocityY += acceleration;
  }
  if (kb.pressing("a") || kb.pressing(LEFT_ARROW)) {
    velocityX -= acceleration;
  }
  if (kb.pressing("d") || kb.pressing(RIGHT_ARROW)) {
    velocityX += acceleration;
  }
}
function spawnEnemy() {
  let x = random(600);
  let y = random(600);

  if (electronCount >= 100 && random() < 0.2) {
    new laserEnemys.Sprite(x, y, 30, "k");
  }

  else if (electronCount >= 50 && random() < 0.3) {
    new powerfulEnemys.Sprite(x, y, 28, "k");
  }

  else {
    new enemys.Sprite(x, y, 25, "k");
  }
  
  enemyCount++;
}
function playerDeath() {
  if (ionaztionenergy <= 0) {
    corePlayer.remove();
    for (let e of electron) {
      e.remove();
    }
    game = false;
  }
}
function title() {
  fill("white");
  noStroke();
  textSize(32);
  textAlign(CENTER, CENTER);
  text("WE'RE JUST BONDING", width / 2, height / 2);
  textSize(16);
  if(ionaztionenergy <= 0){
    text(
      "Game Over!! You used all of your ionization energy",
      width / 2,
      height / 2 + 50
    );
  }
  
  if(electronCount >= 103){
    text(
      "you win!!! this is probably the hardest game I have made so far congratulations",
      width / 2,
      height / 2 + 50
    );
  }
  
  textSize(11);
  text("Press R to Restart", 200, 300);
  if (kb.presses('r')) {
    restartGame();
  }
}
function restartGame() {
  if (corePlayer) corePlayer.remove();
  if (statusShape) statusShape.remove();
  allSprites.removeAll();
  initGame();
}
function playerDefence() {
  if (kb.presses("e") && canUseShield && !enableSheild) {
    enableSheild = true;
    shieldStartTime = millis();
    canUseShield = false;
  }
}
function updateShield() {
  if (enableSheild && millis() - shieldStartTime >= shieldDuration) {
    enableSheild = false;
    shieldCooldownStart = millis();
  }
  if (
    !canUseShield &&
    !enableSheild &&
    millis() - shieldCooldownStart >= shieldCooldown
  ) {
    canUseShield = true;
  }
}
function elementGroupChange() {
  let prevElectronCount = electronCount;
  electronCount = electron.length;
  if (prevElectronCount !== electronCount) {
    if([1, 6, 7, 8, 9, 15, 16, 17, 34, 35, 53].includes(electronCount)) {
      status = 'reactive nonmetal';
      statusColor = 'blue';
      ionaztionenergy = 13.6;
    }
    
    else if([2, 10, 18, 36, 54, 86].includes(electronCount)) {
      status = 'noble gas';
      statusColor = 'rgb(218,46,220)';
      ionaztionenergy = 20.6;
    }
    
    else if([3, 11, 19, 37, 55, 87].includes(electronCount)) {
      status = 'alkali metal';
      statusColor = 'lightblue';
      ionaztionenergy = 20.6
    }
    
    else if([4, 12, 20, 38, 56, 88].includes(electronCount)) {
      status = 'alkaline earth metal';
      statusColor = 'pink';
      ionaztionenergy = 25.2;
    }
    
    else if([5, 14, 32, 33, 51, 52].includes(electronCount)) {
      status = 'metalloid';
      statusColor = 'rgb(236,236,143)';
      ionaztionenergy = 30;
    }
    
    else if([21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 40, 41, 42, 43, 44, 45, 46, 47, 48, 72, 73, 74, 75, 76, 77, 78, 79, 80, 104, 105, 106, 107, 108].includes(electronCount)) {
      status = 'transition metal';
      statusColor = 'purple';
      ionaztionenergy = 31.8;
    }
    
    else if([13, 31, 49, 50, 81, 82, 83, 84, 85].includes(electronCount)) {
      status = 'post-transition metal';
      statusColor = 'lightgreen';
      ionaztionenergy = 35.3;
    }
    
    else if([111, 112, 113, 114, 115, 116, 117, 118].includes(electronCount)) {
      status = 'unknown properties';
      statusColor = 'grey';
      ionaztionenergy = 50;
    }
    
    else if([58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71].includes(electronCount)) {
      status = 'lanthanides';
      statusColor = 'rgb(92,3,3)';
      ionaztionenergy = 65.7;
    }
    
    else if([90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103].includes(electronCount)) {
      status = 'actinide';
      statusColor = 'orange';
      ionaztionenergy = 80;
    }
    
    statusShape.color = statusColor;
  }
}
function win() {
  if (electronCount >= 103) {
    corePlayer.remove();
    for (let e of electron) {
      e.remove();
    }
    game = false;
  }
}
//:)